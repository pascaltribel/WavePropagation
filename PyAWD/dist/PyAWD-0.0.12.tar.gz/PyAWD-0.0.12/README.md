# PyAWD: a Python acoustic wave propagation dataset using PyTorch and Devito
